# 🛡️ FraudShield API

> Plataforma colaborativa de prevenção e denúncia de golpes bancários

![Java](https://img.shields.io/badge/Java-21-orange?style=flat-square&logo=java)
![Spring Boot](https://img.shields.io/badge/Spring_Boot-3.2.5-green?style=flat-square&logo=springboot)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-blue?style=flat-square&logo=postgresql)
![Docker](https://img.shields.io/badge/Docker-ready-blue?style=flat-square&logo=docker)

---

## 📋 Sobre o Projeto

O **FraudShield** é uma plataforma que combate golpes bancários através de:

- 📢 **Denúncias colaborativas** de números suspeitos
- 🔍 **Consulta de telefones** com histórico de golpes
- 📚 **Central educativa** com dicas de segurança
- 🔐 **Autenticação segura** com JWT

---

## 🚀 Como rodar

### Pré-requisitos
- Docker e Docker Compose instalados

### Com Docker (recomendado)

```bash
# Clone o repositório
git clone https://github.com/seu-time/fraudshield-api

# Suba os containers
docker-compose up --build

# API disponível em: http://localhost:8080
# Swagger em: http://localhost:8080/swagger-ui.html
```

### Sem Docker

```bash
# Requisitos: Java 21 + PostgreSQL rodando local

# Configure o banco em src/main/resources/application.properties

# Build e execução
mvn clean install
mvn spring-boot:run
```

---

## 🗂️ Estrutura do Projeto

```
src/main/java/com/fraudshield/
├── controller/     # Endpoints REST
├── service/        # Regras de negócio
├── repository/     # Acesso ao banco (JPA)
├── entity/         # Modelos do banco
├── dto/            # Objetos de transferência
├── config/         # Configurações (Swagger, CORS, Exception Handler)
└── security/       # JWT Filter e JwtService
```

---

## 📡 Endpoints

### Autenticação
| Método | Rota | Descrição | Auth |
|--------|------|-----------|------|
| POST | `/auth/register` | Cadastro de usuário | ❌ |
| POST | `/auth/login` | Login e obtenção de token | ❌ |

### Denúncias
| Método | Rota | Descrição | Auth |
|--------|------|-----------|------|
| GET | `/reports` | Listar todas as denúncias | ✅ |
| POST | `/reports` | Criar nova denúncia | ✅ |
| GET | `/reports/phone/{numero}` | Verificar número suspeito | ❌ |
| DELETE | `/reports/{id}` | Deletar denúncia | ✅ |

### Dicas
| Método | Rota | Descrição | Auth |
|--------|------|-----------|------|
| GET | `/tips` | Listar dicas de segurança | ❌ |
| POST | `/tips` | Criar nova dica | ✅ |

---

## 🔐 Autenticação

A API usa **JWT (JSON Web Token)**. Após login, inclua o token no header:

```
Authorization: Bearer {seu_token}
```

---

## 🏗️ Stack Tecnológica

| Camada | Tecnologia |
|--------|-----------|
| Backend | Java 21 + Spring Boot 3.2 |
| Segurança | Spring Security + JWT |
| Banco | PostgreSQL 16 |
| ORM | Spring Data JPA / Hibernate |
| Documentação | Springdoc OpenAPI (Swagger) |
| Container | Docker + Docker Compose |

---

## 📊 Modelo do Banco

### users
| Campo | Tipo |
|-------|------|
| id | BIGSERIAL PK |
| name | VARCHAR |
| email | VARCHAR UNIQUE |
| password | VARCHAR (BCrypt) |
| created_at | TIMESTAMP |

### reports
| Campo | Tipo |
|-------|------|
| id | BIGSERIAL PK |
| phone_number | VARCHAR |
| description | TEXT |
| risk_level | ENUM (BAIXO/MEDIO/ALTO/CRITICO) |
| scam_type | ENUM |
| created_at | TIMESTAMP |
| user_id | FK → users |

### tips
| Campo | Tipo |
|-------|------|
| id | BIGSERIAL PK |
| title | VARCHAR |
| content | TEXT |
| category | VARCHAR |
| icon_url | VARCHAR |

---

## 🧪 Testando com cURL

```bash
# 1. Registrar usuário
curl -X POST http://localhost:8080/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"João Silva","email":"joao@email.com","password":"123456"}'

# 2. Login
curl -X POST http://localhost:8080/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"joao@email.com","password":"123456"}'

# 3. Criar denúncia (use o token do login)
curl -X POST http://localhost:8080/reports \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber":"11999998888","description":"Ligaram se passando pelo Bradesco pedindo minha senha","riskLevel":"ALTO","scamType":"FALSO_BANCO"}'

# 4. Verificar número (público, sem token)
curl http://localhost:8080/reports/phone/11999998888
```

---

## 👥 Time

Desenvolvido para o **Hackathon Bradesco 2024** 🏆
