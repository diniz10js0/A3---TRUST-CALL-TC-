package com.fraudshield.service;

import com.fraudshield.dto.TipRequest;
import com.fraudshield.dto.TipResponse;
import com.fraudshield.entity.Tip;
import com.fraudshield.repository.TipRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TipService {

    private final TipRepository tipRepository;

    public List<TipResponse> getAllTips() {
        return tipRepository.findAll()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public TipResponse createTip(TipRequest request) {
        Tip tip = Tip.builder()
                .title(request.getTitle())
                .content(request.getContent())
                .category(request.getCategory())
                .iconUrl(request.getIconUrl())
                .build();

        return toResponse(tipRepository.save(tip));
    }

    private TipResponse toResponse(Tip tip) {
        TipResponse response = new TipResponse();
        response.setId(tip.getId());
        response.setTitle(tip.getTitle());
        response.setContent(tip.getContent());
        response.setCategory(tip.getCategory());
        response.setIconUrl(tip.getIconUrl());
        return response;
    }
}
