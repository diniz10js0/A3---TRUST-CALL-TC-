package com.fraudshield.service;

import com.fraudshield.dto.PhoneCheckResponse;
import com.fraudshield.dto.ReportRequest;
import com.fraudshield.dto.ReportResponse;
import com.fraudshield.entity.Report;
import com.fraudshield.entity.User;
import com.fraudshield.repository.ReportRepository;
import com.fraudshield.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final ReportRepository reportRepository;
    private final UserRepository userRepository;

    public List<ReportResponse> getAllReports() {
        return reportRepository.findAllByOrderByCreatedAtDesc()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    public ReportResponse createReport(ReportRequest request) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        Report report = Report.builder()
                .phoneNumber(request.getPhoneNumber())
                .description(request.getDescription())
                .riskLevel(request.getRiskLevel())
                .scamType(request.getScamType())
                .user(user)
                .build();

        return toResponse(reportRepository.save(report));
    }

    public PhoneCheckResponse checkPhone(String phoneNumber) {
        List<ReportResponse> reports = reportRepository
                .findByPhoneNumberOrderByCreatedAtDesc(phoneNumber)
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());

        return new PhoneCheckResponse(phoneNumber, reports);
    }

    public void deleteReport(Long id) {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        Report report = reportRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Denúncia não encontrada"));

        if (!report.getUser().getEmail().equals(email)) {
            throw new RuntimeException("Sem permissão para deletar esta denúncia");
        }

        reportRepository.delete(report);
    }

    private ReportResponse toResponse(Report report) {
        ReportResponse response = new ReportResponse();
        response.setId(report.getId());
        response.setPhoneNumber(report.getPhoneNumber());
        response.setDescription(report.getDescription());
        response.setRiskLevel(report.getRiskLevel());
        response.setScamType(report.getScamType());
        response.setCreatedAt(report.getCreatedAt());
        response.setUserName(report.getUser() != null ? report.getUser().getName() : "Anônimo");
        return response;
    }
}
