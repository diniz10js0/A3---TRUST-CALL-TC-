package com.fraudshield.controller;

import com.fraudshield.dto.PhoneCheckResponse;
import com.fraudshield.dto.ReportRequest;
import com.fraudshield.dto.ReportResponse;
import com.fraudshield.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
@Tag(name = "Denúncias", description = "Gerenciamento de denúncias de golpes")
public class ReportController {

    private final ReportService reportService;

    @GetMapping
    @Operation(summary = "Listar todas as denúncias", security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<List<ReportResponse>> getAllReports() {
        return ResponseEntity.ok(reportService.getAllReports());
    }

    @PostMapping
    @Operation(summary = "Criar nova denúncia", security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<ReportResponse> createReport(@Valid @RequestBody ReportRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reportService.createReport(request));
    }

    @GetMapping("/phone/{phoneNumber}")
    @Operation(summary = "Verificar número de telefone suspeito (público)")
    public ResponseEntity<PhoneCheckResponse> checkPhone(@PathVariable String phoneNumber) {
        return ResponseEntity.ok(reportService.checkPhone(phoneNumber));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deletar denúncia", security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<Void> deleteReport(@PathVariable Long id) {
        reportService.deleteReport(id);
        return ResponseEntity.noContent().build();
    }
}
