package com.fraudshield.controller;

import com.fraudshield.dto.TipRequest;
import com.fraudshield.dto.TipResponse;
import com.fraudshield.service.TipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tips")
@RequiredArgsConstructor
@Tag(name = "Dicas de Segurança", description = "Central educativa anti-golpes")
public class TipController {

    private final TipService tipService;

    @GetMapping
    @Operation(summary = "Listar todas as dicas (público)")
    public ResponseEntity<List<TipResponse>> getAllTips() {
        return ResponseEntity.ok(tipService.getAllTips());
    }

    @PostMapping
    @Operation(summary = "Criar nova dica", security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity<TipResponse> createTip(@Valid @RequestBody TipRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(tipService.createTip(request));
    }
}
