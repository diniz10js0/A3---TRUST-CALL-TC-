package com.fraudshield.repository;

import com.fraudshield.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {

    List<Report> findByPhoneNumberOrderByCreatedAtDesc(String phoneNumber);

    List<Report> findAllByOrderByCreatedAtDesc();

    @Query("SELECT COUNT(r) FROM Report r WHERE r.phoneNumber = :phoneNumber")
    int countByPhoneNumber(String phoneNumber);

    @Query("SELECT r FROM Report r WHERE r.user.id = :userId ORDER BY r.createdAt DESC")
    List<Report> findByUserId(Long userId);
}
