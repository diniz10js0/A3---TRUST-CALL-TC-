package com.fraudshield.config;

import com.fraudshield.entity.Tip;
import com.fraudshield.repository.TipRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {

    private final TipRepository tipRepository;

    @Override
    public void run(String... args) {
        if (tipRepository.count() > 0) return;

        List<Tip> tips = List.of(
            Tip.builder()
                .title("Nunca forneça sua senha por telefone")
                .content("Bancos NUNCA ligam pedindo senha, token ou código. Se receber essa ligação, desligue imediatamente e ligue para o número oficial do seu banco no verso do cartão.")
                .category("LIGACAO")
                .iconUrl("🔒")
                .build(),
            Tip.builder()
                .title("Desconfie de urgência e pressão")
                .content("Golpistas criam senso de urgência para impedir que você pense. Frases como 'sua conta será bloqueada agora' ou 'você tem 5 minutos' são sinais claros de golpe.")
                .category("PSICOLOGIA")
                .iconUrl("⚠️")
                .build(),
            Tip.builder()
                .title("Verifique o número antes de atender")
                .content("Números de bancos geralmente começam com 0800 ou são os mesmos do verso do cartão. Números desconhecidos, internacionais ou de celular pedindo dados são suspeitos.")
                .category("LIGACAO")
                .iconUrl("📞")
                .build(),
            Tip.builder()
                .title("Cuidado com PIX e transferências urgentes")
                .content("Se alguém pede PIX urgente mesmo sendo 'familiar em apuro', confirme a identidade por videochamada ou ligando direto para o número salvo em seus contatos.")
                .category("PIX")
                .iconUrl("💸")
                .build(),
            Tip.builder()
                .title("Links suspeitos no WhatsApp")
                .content("Não clique em links recebidos por WhatsApp de números desconhecidos. Promoções impossíveis, prêmios e sorteios são iscas comuns para roubo de dados.")
                .category("WHATSAPP")
                .iconUrl("📱")
                .build(),
            Tip.builder()
                .title("Ative o duplo fator de autenticação")
                .content("Sempre ative o 2FA (autenticação em dois fatores) no aplicativo do banco, e-mail e redes sociais. Isso dificulta muito o acesso de golpistas mesmo que tenham sua senha.")
                .category("SEGURANCA_DIGITAL")
                .iconUrl("🛡️")
                .build()
        );

        tipRepository.saveAll(tips);
        System.out.println("✅ Dados iniciais carregados com sucesso!");
    }
}
