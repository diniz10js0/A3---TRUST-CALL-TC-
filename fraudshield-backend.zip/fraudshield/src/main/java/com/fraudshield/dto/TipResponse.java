package com.fraudshield.dto;

import lombok.Data;

@Data
public class TipResponse {
    private Long id;
    private String title;
    private String content;
    private String category;
    private String iconUrl;
}
