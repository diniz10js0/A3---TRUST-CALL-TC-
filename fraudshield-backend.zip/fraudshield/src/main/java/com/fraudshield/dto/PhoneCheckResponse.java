package com.fraudshield.dto;

import lombok.Data;

import java.util.List;

@Data
public class PhoneCheckResponse {
    private String phoneNumber;
    private int totalReports;
    private String overallRisk;
    private List<ReportResponse> reports;

    public PhoneCheckResponse(String phoneNumber, List<ReportResponse> reports) {
        this.phoneNumber = phoneNumber;
        this.reports = reports;
        this.totalReports = reports.size();
        this.overallRisk = calculateRisk(reports.size());
    }

    private String calculateRisk(int count) {
        if (count == 0) return "SEM_REGISTROS";
        if (count <= 2) return "BAIXO";
        if (count <= 5) return "MEDIO";
        if (count <= 10) return "ALTO";
        return "CRITICO";
    }
}
