package com.fraudshield.dto;

import com.fraudshield.entity.Report;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ReportResponse {
    private Long id;
    private String phoneNumber;
    private String description;
    private Report.RiskLevel riskLevel;
    private Report.ScamType scamType;
    private LocalDateTime createdAt;
    private String userName;
}
