package com.fraudshield.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TipRequest {

    @NotBlank(message = "Título é obrigatório")
    private String title;

    @NotBlank(message = "Conteúdo é obrigatório")
    private String content;

    @NotBlank(message = "Categoria é obrigatória")
    private String category;

    private String iconUrl;
}
