package com.fraudshield.dto;

import com.fraudshield.entity.Report;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ReportRequest {

    @NotBlank(message = "Número de telefone é obrigatório")
    private String phoneNumber;

    @NotBlank(message = "Descrição é obrigatória")
    @Size(min = 10, message = "Descrição muito curta, informe mais detalhes")
    private String description;

    @NotNull(message = "Nível de risco é obrigatório")
    private Report.RiskLevel riskLevel;

    private Report.ScamType scamType;
}
